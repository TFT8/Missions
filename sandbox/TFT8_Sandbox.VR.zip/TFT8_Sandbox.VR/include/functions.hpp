class TFT	//tag
{
	class S6	//category
	{
		class enableCamera {
			file  = "functions\enableCamera.sqf";
		};
	};
	class S3	//category
	{
		class drawBuildingMarker {
			file  = "functions\drawBuildingMarker.sqf";
		};
	};
};