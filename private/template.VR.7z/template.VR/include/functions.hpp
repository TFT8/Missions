class CfgFunctions
{
	class TFT	//tag
	{
		class Marker	//category
		{
			class drawBuildingMarker {
				file  = "functions\drawBuildingMarker.sqf";
			};
		};
	};
};
