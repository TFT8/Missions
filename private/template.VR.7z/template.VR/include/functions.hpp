class CfgFunctions
{
	class TFT	//tag
	{
		class Marker	//category
		{
			class drawBuildingMarker {
				file  = "functions\drawBuildingMarker.sqf";
			};
		};
		class Loadouts	//category
		{
			class defaultLoadouts {
				file  = "functions\defaultLoadouts.sqf";
			};
		};
	};
};
