class TFT	//tag
{
	class Marker	//category
	{
		class drawBuildingMarker {
			file  = "functions\drawBuildingMarker.sqf";
		};
	};
	class Loadouts	//category
	{
		class defaultLoadouts {
			file  = "functions\defaultLoadouts.sqf";
		};
	};
	class S6	//category
	{
		class enableCamera {
			file  = "functions\enableCamera.sqf";
		};
	};
	class S3	//category
	{
		class toggleDoor {
			file  = "functions\toggleDoor.sqf";
		};
		class toggleLight {
			file  = "functions\toggleLight.sqf";
		};
	};
};