class TFT	//tag
{
	class S6	//category
	{
		class enableCamera {
			file  = "functions\enableCamera.sqf";
		};
	};
	class S3	//category
	{
		class drawBuildingMarker {
			file  = "functions\drawBuildingMarker.sqf";
		};
		class toggleDoor {
			file  = "functions\toggleDoor.sqf";
		};
		class toggleLight {
			file  = "functions\toggleLight.sqf";
		};
		class zeusSpawnAir {
			file  = "functions\zeusSpawnAir.sqf";
		};
	};
};